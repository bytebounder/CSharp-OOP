﻿namespace _02.PointInRectangle
{
    using System;
    using System.Linq;

    class PointInRectangle
    {
        static void Main(string[] args)
        {
            var coordinates = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            var n = int.Parse(Console.ReadLine());

            var point1 = new Point(coordinates[0], coordinates[1]);
            var point2 = new Point(coordinates[2], coordinates[3]);

            var rectangle = new Rectangle(point1, point2);

            for (int i = 0; i < n; i++)
            {
                var points = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                var x = points[0];
                var y = points[1];
                var point = new Point(x , y);

                if (rectangle.Contains(point))
                {
                    Console.WriteLine("True");
                }
                else
                {
                    Console.WriteLine("False");
                }
            }
        }
    }
}