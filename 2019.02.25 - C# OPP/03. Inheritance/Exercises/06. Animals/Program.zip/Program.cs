﻿using Exercise.Core;

namespace Exercise
{
    public class Program
    {
        public static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}